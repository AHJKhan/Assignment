package anamulKhan.Test1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class base {
	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver",
			"F:\\Selenium Software\\PRP\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/");
	driver.manage().window().maximize();
	driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
	driver.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
	driver.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("Anamul");
	driver.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("Hoque");
	Select DateOfBirthDay = new Select(driver.findElement(By.name("DateOfBirthDay")));
	DateOfBirthDay.selectByVisibleText("6");
	Select DateOfBirthMonth = new Select(driver.findElement(By.name("DateOfBirthMonth")));
	DateOfBirthMonth.selectByVisibleText("January");
	Select DateOfBirthYear = new Select(driver.findElement(By.name("DateOfBirthYear")));
	DateOfBirthYear.selectByVisibleText("1990");
	driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("jehadkhan89@gmail.com");
	driver.findElement(By.xpath("//*[@id=\"Company\"]")).sendKeys("K&K Company Ltd");
	driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("K@K12345");
	driver.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys("K@K12345");
	driver.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
	}

}




