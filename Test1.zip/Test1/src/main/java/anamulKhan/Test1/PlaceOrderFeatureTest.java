package anamulKhan.Test1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PlaceOrderFeatureTest {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"F:\\Selenium Software\\PRP\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
			driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div/div[3]/div/div[1]/div/div/a/img")).click();
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div[3]/div/div[2]/div[1]/div/div[2]/div/div/a/img")).click();
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div[3]/div/div[2]/div[2]/div[2]/div/div/div[3]/div/div[1]/a/img")).click();
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-20\"]")).click();
		Thread.sleep(6000);
		driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();
		driver.findElement(By.name("termsofservice")).click();
		driver.findElement(By.name("checkout")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[1]/div[3]/button[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.name("BillingNewAddress.FirstName")).sendKeys("Anamul");
		driver.findElement(By.name("BillingNewAddress.LastName")).sendKeys("Hoque");
		driver.findElement(By.name("BillingNewAddress.Email")).sendKeys("jehadkhan89@gmail.com");
		driver.findElement(By.name("BillingNewAddress.Company")).sendKeys("K&K Company Ltd");
		Select BillingNewAddress = new Select(driver.findElement(By.name("BillingNewAddress.CountryId")));
		BillingNewAddress.selectByVisibleText("Bangladesh");
		Thread.sleep(3000);
        Select BillingNewAddress2 = new Select(driver.findElement(By.name("BillingNewAddress.StateProvinceId")));
        BillingNewAddress2.selectByVisibleText("Other");
		driver.findElement(By.name("BillingNewAddress.City")).sendKeys("Dhaka");
		driver.findElement(By.name("BillingNewAddress.Address1")).sendKeys("House-19, Road-6,Session-12");
		driver.findElement(By.name("BillingNewAddress.Address2")).sendKeys("Mirpur-12, Pallabi");
		driver.findElement(By.name("BillingNewAddress.ZipPostalCode")).sendKeys("1216");
		driver.findElement(By.name("BillingNewAddress.PhoneNumber")).sendKeys("+8801737119706");
		driver.findElement(By.name("BillingNewAddress.FaxNumber")).sendKeys("0278987656");
		driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/button[4]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"shipping-methods-form\"]/ul/li[2]/div[1]/label")).click();
		driver.findElement(By.xpath("//*[@id=\"shipping-method-buttons-container\"]/button")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"payment-method-block\"]/li[2]/div/div[1]/label/img")).click();
		driver.findElement(By.xpath("//*[@id=\"payment-method-buttons-container\"]/button")).click();
		Thread.sleep(2000);
		 Select CreditCardType = new Select(driver.findElement(By.name("CreditCardType")));
		 CreditCardType.selectByVisibleText("Visa");
		 
		 driver.findElement(By.name("CardholderName")).sendKeys("Anamul Hoque");
			driver.findElement(By.name("CardNumber")).sendKeys("1111185555755555");
			
			Select ExpireYear = new Select(driver.findElement(By.name("ExpireYear")));
			ExpireYear.selectByVisibleText("2028");
			driver.findElement(By.name("CardCode")).sendKeys("227");
			driver.findElement(By.xpath("//*[@id=\"payment-info-buttons-container\"]/button")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"confirm-order-buttons-container\"]/button")).click();
			//Thank you//
			// Your order has been successfully processed!//

	}

}
