package junit.framework;

public class Test {

}
